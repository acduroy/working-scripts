mac=$(dmesg | grep \'rndis_host\' )
mac_t=$(echo $mac | rev | cut -d" " -f 1 | rev)
echo $mac_t
for i in $( ls /sys/class/net )
do
  addr=$(cat /sys/class/net/$i/address)
  if echo "$addr" | grep -qwi $mac_t
  then
          echo $i
	  ip_addr=$(ip addr show $i | grep "inet\b" | awk '{print $2}' | cut -d/ -f1)
	  if [[ -z "$ip_addr" && -z "$1" ]];
	  then
	  	 echo "using 169.254.3.1 to set host interface ip" 
                 ip link set dev $i up
                 ip addr add 169.254.3.1/255.255.255.0 dev $i
          elif [ "$ip_addr" == "$1" ];
          then
		 echo "input ip is same as default setting, please reset"
          elif [[ -n "$ip_addr" && -z "$1" ]];
          then
		  echo "Host interface already enable"
          else
                 echo "using $1 to set host interface ip"
                 ip link set dev $i up
                 #ip addr del $ip_addr dev $i
                 #ip addr add $1/255.255.255.0 dev $i
                 ip addr flush to $ip_addr/255.255.255.0 dev $i
                 ip addr add $1/255.255.255.0 dev $i
                

          fi
          exit 0
  fi
done
exit 1 
