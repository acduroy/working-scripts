mac=$(dmesg | grep \'rndis_host\' )
mac_t=$(echo $mac | rev | cut -d" " -f 1 | rev)
echo $mac_t
for i in $( ls /sys/class/net )
do
  addr=$(cat /sys/class/net/$i/address)
  if echo "$addr" | grep -qwi $mac_t
  then
          echo $i
          iptables -A INPUT -i $i -j ACCEPT
          iptables -A OUTPUT -o $i -j ACCEPT
          iptables -A FORWARD -i $i -j ACCEPT
          iptables -A FORWARD -o $i -j ACCEPT
          break
  fi
done
systemctl restart SuSEfirewall2 SuSEfirewall2_init
